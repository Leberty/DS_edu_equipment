﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace NF2021_API.Controllers
{
    public class EquipmentController : ApiController
    {
        // GET api/values/5
        [Route("api/Equipment/State")]
        public IHttpActionResult Get(string serialNumber)
        {
            if (ListEquipments.Contains(serialNumber))
            {
                return Ok(new Random().Next(0, 2));
            }
            else
            {
                return NotFound();
            }
        }

        public static List<string> ListEquipments = new List<string>
        {
            "М0123ТНС312",
"М234ТНС12",
"М567ТНС87",
"М455ТНС567",
"М8888ТНС231",
"М67ТНС98008",
"М43535ТНС2677",
"М535623ТНС8899",
"М431ТНС7647",
"М654ТНС878",
"М634ТНС67",
"М877ТНС132",
"СД12ТНС_01",
"СД12ТНС_02",
"СД12ТНС_03",
"СД12ТНС_04",
"СД12ТНС_05",
"СД12ТНС_06",
"СД12ТНС_07",
"СД12ТНС_08",
"СД12ТНС_09",
"СД12ТНС_10",
"СД12ТНС_11",
"СД12ТНС_12",
"СД12ТНС_13",
"СД12ТНС_14",
"СД12ТНС_15",
"СД12ТНС_16",
"СД12ТНС_17",
"СД12ТНС_18",
"СД12ТНС_19",
"СД12ТНС_20",
"СД12ТНС_21",
"СД12ТНС_22",
"СД12ТНС_23",
"СД12ТНС_24",
"СД12ТНС_25",
"СД12ТНС_26",
"СД12ТНС_27",
"СД12ТНС_28",
"СД12ТНС_29",
"СД12ТНС_30",
"АО567-ТНС-11",
"АО567-ТНС-12",
"АО567-ТНС-13",
"АО567-ТНС-14"
        };
    }
}
