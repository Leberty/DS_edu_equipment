﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace NF2021_API.Controllers
{
    public class BaseStationController : ApiController
    {
        public IHttpActionResult Get(int id)
        {
            if (new List<int>(){ 1,2,3,4,5}.Contains(id))
            {
                return Ok(new Random().Next(9, 22));
            }
            else
            {
                return NotFound();
            }
        }
    }
}
